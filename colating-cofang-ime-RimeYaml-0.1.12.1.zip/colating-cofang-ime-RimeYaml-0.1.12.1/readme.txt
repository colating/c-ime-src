Colating IME输入法说明：

The Colating IME user manual, Use the txt editor to open the file
"colating-ime-char.schema.yaml" and see it.
